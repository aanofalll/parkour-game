extends Area2D

@onready var timer = $Timer
var died = false

func _on_body_entered(body):
	if died:
		return
	died = true
	print("You died!")

	if body is CharacterBody2D:
		body.velocity = Vector2.ZERO

	var collision = body.get_node_or_null("CollisionShape2D")
	if collision != null:
		collision.disabled = true

	# تعديل: جعل وقت الانتظار نصف ثانية فقط (0.5) قبل إعادة التشغيل
	timer.wait_time = 0.5
	timer.start()

func _on_timer_timeout():
	get_tree().reload_current_scene()
