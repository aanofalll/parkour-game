extends CharacterBody2D

const SPEED = 140.0
const JUMP_VELOCITY = -300.0
const DEATH_Y_LIMIT = 600.0  

var is_dead = false

func _physics_process(delta: float) -> void:
	# 
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor() and not is_dead:
		velocity.y = JUMP_VELOCITY


	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

	
	if not is_dead and global_position.y > DEATH_Y_LIMIT:
		die()

func die() -> void:
	is_dead = true
	get_tree().reload_current_scene()
