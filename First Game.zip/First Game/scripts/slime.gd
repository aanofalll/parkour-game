extends Node2D

const SPEED = 60

var direction = 1

@onready var ray_cast_right = $RayCastRight
@onready var ray_cast_left = $RayCastLeft
@onready var animated_sprite = $AnimatedSprite2D
@onready var hitbox = $Area2D

func _ready():
	if hitbox:
		hitbox.body_entered.connect(_on_hitbox_body_entered)

func _process(delta):
	if ray_cast_right and ray_cast_right.is_colliding():
		direction = -1
		if animated_sprite:
			animated_sprite.flip_h = true
		
	if ray_cast_left and ray_cast_left.is_colliding():
		direction = 1
		if animated_sprite:
			animated_sprite.flip_h = false
	
	position.x += direction * SPEED * delta

func _on_hitbox_body_entered(body):
	if body.is_in_group("player"):
		body.queue_free() 
		
		get_tree().reload_current_scene()
