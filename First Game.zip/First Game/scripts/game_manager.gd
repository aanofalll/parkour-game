extends Node

var score = 0

func add_point():
	score += 1
	var label = get_tree().current_scene.find_child("ScoreLabel", true, false)
	if label:
		label.text = "You collected " + str(score) + " coins."
